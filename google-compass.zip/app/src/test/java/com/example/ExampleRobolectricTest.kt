package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.UserProfile
import com.example.rag.DocumentSearchEngine
import com.example.service.CompassMentorService
import com.example.service.NetworkSecurityService
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Google Compass", appName)
  }

  @Test
  fun `verify RAG document retrieval`() {
    val chunks = DocumentSearchEngine.retrieveRelevantChunks("What should I do in my first 30 days?")
    assertTrue("Should retrieve at least one chunk for onboarding", chunks.isNotEmpty())
    val mentorChunks = DocumentSearchEngine.retrieveRelevantChunks("How do I find a mentor?")
    assertTrue("Should retrieve mentor handbook chunk", mentorChunks.any { it.documentName.contains("Mentorship") })
  }

  @Test
  fun `verify network access check abstraction`() {
    NetworkSecurityService.toggleAccessForDemo(true)
    assertTrue(NetworkSecurityService.NETWORK_ACCESS_CHECK())

    NetworkSecurityService.toggleAccessForDemo(false)
    assertFalse(NetworkSecurityService.NETWORK_ACCESS_CHECK())

    // Restore state
    NetworkSecurityService.toggleAccessForDemo(true)
    assertTrue(NetworkSecurityService.NETWORK_ACCESS_CHECK())
  }

  @Test
  fun `verify mentor guidance synthesis from information to intention`() = runBlocking {
    val profile = UserProfile()
    val response = CompassMentorService.generateMentorResponse(
      "I'm new to Trimble. I feel a little overwhelmed. What should I focus on?",
      profile
    )
    assertTrue(response.text.contains("Welcome to Trimble"))
    assertTrue(response.sources.isNotEmpty())
    assertEquals("Complete the First 30 Days Checklist on Trimble Learn and schedule your recurring weekly 1:1 with ${profile.manager}.", response.recommendedAction)
  }

  @Test
  fun `verify dashboard profile and snapshot metrics`() {
    val profile = UserProfile()
    assertEquals("Alex", profile.name)
    assertEquals("Data Analyst", profile.role)
    assertEquals(14, profile.daysAtTrimble)

    val snapshot = com.example.model.GrowthSnapshot()
    assertEquals(com.example.model.GrowthStatus.EXPLORE, snapshot.trimbleKnowledge)
    assertEquals(com.example.model.GrowthStatus.DEVELOPING, snapshot.roleReadiness)
    assertEquals(com.example.model.GrowthStatus.DEVELOPING, snapshot.communication)
    assertEquals(com.example.model.GrowthStatus.EXPLORE, snapshot.careerClarity)
  }
}

