package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.*
import com.example.service.CompassMentorService
import com.example.service.NetworkSecurityService
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                GoogleCompassApp()
            }
        }
    }
}

@Composable
fun GoogleCompassApp() {
    val coroutineScope = rememberCoroutineScope()
    val configuration = LocalConfiguration.current
    val isWideScreen = configuration.screenWidthDp >= 720

    val networkState by NetworkSecurityService.accessState.collectAsStateWithLifecycle()
    var isDemoBarVisible by remember { mutableStateOf(true) }
    var currentSection by remember { mutableStateOf(NavigationSection.DASHBOARD) }

    // User Profile
    val userProfile = remember { UserProfile() }

    // Growth Snapshot state
    var growthSnapshot by remember { mutableStateOf(GrowthSnapshot()) }

    // 30-Day Plan state (Weeks 1 to 4)
    var thirtyDayWeeks by remember {
        mutableStateOf(
            listOf(
                ThirtyDayWeek(
                    weekNumber = 1,
                    title = "Understand Trimble",
                    goal = "Absorb company heritage, core values, and complete compliance essentials.",
                    activities = listOf(
                        PlanActivity("w1_a1", "Complete Cyber & Compliance Modules", "Finish mandatory data protection on Trimble Learn", "Trimble Global Orientation (p. 12)", true),
                        PlanActivity("w1_a2", "Explore Trimble's 4 Business Units", "Review Connected Construction, Geospatial, Ag, and Transportation", "Trimble Global Orientation (p. 18)", true),
                        PlanActivity("w1_a3", "Schedule Initial 1:1 with People Manager", "Align on onboarding expectations with Sarah Jenkins", "Trimble Global Orientation (p. 12)", true),
                        PlanActivity("w1_a4", "Meet Onboarding Buddy", "Introductory coffee chat on squad norms and Slack channels", "Trimble Global Orientation (p. 12)", false)
                    )
                ),
                ThirtyDayWeek(
                    weekNumber = 2,
                    title = "Understand Your Product & Team",
                    goal = "Deep dive into your product architecture, telemetry pipelines, and sprint rhythm.",
                    activities = listOf(
                        PlanActivity("w2_a1", "Explore Trimble Connect Cloud Architecture", "Understand how field sensors publish IoT telemetry", "Engineering Standards (p. 5)", false),
                        PlanActivity("w2_a2", "Shadow a Sprint Retrospective & Planning", "Observe agile ceremonies and team velocity tracking", "Trimble Orientation (p. 8)", false),
                        PlanActivity("w2_a3", "Review Team Git Repositories & Style Guide", "Setup local development environment following GitLab style guide", "Engineering Standards (p. 5)", false),
                        PlanActivity("w2_a4", "Request a Cross-Functional Mentor", "Submit profile on Trimble People Portal > Growth & Mentorship", "Mentorship Handbook (p. 6)", false)
                    )
                ),
                ThirtyDayWeek(
                    weekNumber = 3,
                    title = "Develop Role-Specific Skills",
                    goal = "Execute your first analytical query pipelines with peer review rigor.",
                    activities = listOf(
                        PlanActivity("w3_a1", "Build Snowflake Telemetry Query", "Extract field equipment metrics for Connected Construction", "Engineering Standards (p. 5)", false),
                        PlanActivity("w3_a2", "Submit First Merge Request for Peer Review", "Collaborative review with Staff Engineer Priya Sharma", "Engineering Standards (p. 11)", false),
                        PlanActivity("w3_a3", "Activate Enterprise Coursera Learning Account", "Begin Data Engineering and Snowflake optimization module", "Employee Networks (p. 9)", false)
                    )
                ),
                ThirtyDayWeek(
                    weekNumber = 4,
                    title = "Communication + Collaboration",
                    goal = "Present project update using BLUF format and join employee networks.",
                    activities = listOf(
                        PlanActivity("w4_a1", "Practice Sprint Update in Communication Coach", "Refine project update script using BLUF structure", "Workplace Communication Guide (p. 15)", false),
                        PlanActivity("w4_a2", "Deliver 2-Minute Sprint Demo", "Present telemetry pipeline validation to squad", "Workplace Communication Guide (p. 15)", false),
                        PlanActivity("w4_a3", "Join Early Career Professionals Network (ECPN)", "Attend monthly fresher tech-talk and connect with peers", "Employee Networks Guide (p. 3)", false),
                        PlanActivity("w4_a4", "Conduct 30-Day Onboarding Review with Manager", "Evaluate initial goals and define 60-day roadmap", "Mentorship Handbook (p. 21)", false)
                    )
                )
            )
        )
    }

    // Goals state
    var goals by remember {
        mutableStateOf(
            listOf(
                Goal(
                    id = "g1",
                    title = "Improve Stakeholder Communication",
                    description = "Master executive presentation clarity and the BLUF framework for analytics updates.",
                    category = "Communication",
                    targetDays = 60,
                    milestones = listOf(
                        Milestone("m1_1", "Complete communication learning module on Trimble Learn", true),
                        Milestone("m1_2", "Practice two sprint updates with Communication Coach", false),
                        Milestone("m1_3", "Present telemetry findings in bi-weekly team review", false),
                        Milestone("m1_4", "Request structured feedback from People Manager", false)
                    )
                ),
                Goal(
                    id = "g2",
                    title = "Master Trimble Connect Analytics Feeds",
                    description = "Build autonomous pipelines querying IoT sensor telemetry in Snowflake.",
                    category = "Technical",
                    targetDays = 45,
                    milestones = listOf(
                        Milestone("m2_1", "Review GitLab Analytics Style Guide", true),
                        Milestone("m2_2", "Complete Snowflake telemetry schema onboarding", false),
                        Milestone("m2_3", "Submit first peer-reviewed analytics pipeline", false)
                    )
                )
            )
        )
    }

    // Chat History pre-loaded with the Flagship Demo Journey (Requirement 18)
    var chatMessages by remember {
        mutableStateOf(
            listOf(
                ChatMessage(
                    id = "msg_user_1",
                    text = "I'm new to Trimble. I feel a little overwhelmed. What should I focus on?",
                    isUser = true,
                    timestamp = System.currentTimeMillis() - 60000
                ),
                ChatMessage(
                    id = "msg_asst_1",
                    text = """
                        Welcome to Trimble, Alex! First, take a deep breath. It is completely natural to feel overwhelmed during your first few weeks—Trimble is a vast global organization spanning construction, geospatial, agriculture, and transportation.

                        As a newly joined Data Analyst, your primary goal right now is not to know everything immediately. It's to build strong foundations, understand team rhythms, and establish clarity.

                        Here is how to focus your energy:

                        1. What this means: Your initial 30 days are designed for absorption, context-building, and learning team norms rather than solo delivery pressure.
                        2. Why it matters: Building genuine context on our technology ecosystem (like Trimble Connect and our Snowflake telemetry pipelines) will make all your future data work 10x faster.
                        3. What to do next: Prioritize your core onboarding checklist: finish cyber compliance, meet your onboarding buddy, and shadow your team's upcoming sprint retrospective.
                    """.trimIndent(),
                    isUser = false,
                    sources = listOf(
                        com.example.rag.TrimbleKnowledgeBase.documents[2], // First 30 days checklist (p. 12)
                        com.example.rag.TrimbleKnowledgeBase.documents[1]  // Core values (p. 8)
                    ),
                    isGeneralGuidance = false,
                    intentAnalysis = "New employee feeling cognitive overload; seeking orientation priorities and supportive reassurance.",
                    developmentNeed = "Transition from fresher ambiguity into structured onboarding milestones.",
                    recommendedAction = "Complete the First 30 Days Checklist on Trimble Learn and schedule your recurring weekly 1:1 with Sarah Jenkins.",
                    suggestedGoal = "Complete Trimble Orientation & schedule 1:1 with Team Buddy by Day 20."
                )
            )
        )
    }

    // Handle Back Press to return to Dashboard
    BackHandler(enabled = currentSection != NavigationSection.DASHBOARD) {
        currentSection = NavigationSection.DASHBOARD
    }

    // Function to send message
    fun handleSendMessage(text: String) {
        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            text = text,
            isUser = true
        )
        chatMessages = chatMessages + userMsg

        coroutineScope.launch {
            val responseMsg = CompassMentorService.generateMentorResponse(text, userProfile)
            chatMessages = chatMessages + responseMsg
        }
    }

    // Preset Demo Pathways (Requirement 23)
    fun handleDemoPreset(preset: String) {
        when (preset) {
            "welcome" -> {
                currentSection = NavigationSection.ASK_COMPASS
                handleSendMessage("I'm new to Trimble. I feel a little overwhelmed. What should I focus on?")
            }
            "rag_cite" -> {
                currentSection = NavigationSection.ASK_COMPASS
                handleSendMessage("What should I learn in my first 30 days according to the Global Orientation Guide?")
            }
            "assessment" -> {
                currentSection = NavigationSection.GROWTH
            }
            "plan" -> {
                currentSection = NavigationSection.THIRTY_DAY_PLAN
            }
            "career" -> {
                currentSection = NavigationSection.CAREER_COMPASS
            }
            "comm_coach" -> {
                currentSection = NavigationSection.COMMUNICATION_COACH
            }
            "goals" -> {
                currentSection = NavigationSection.GOALS
            }
        }
    }

    // Check if network access is blocked by the NETWORK_ACCESS_CHECK abstraction
    if (!networkState.isAuthorized) {
        NetworkBlockedScreen(
            onReconnect = {
                NetworkSecurityService.toggleAccessForDemo(true)
            }
        )
        return
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            Column {
                GoogleCompassTopBar(
                    networkState = networkState,
                    isDemoBarVisible = isDemoBarVisible,
                    onToggleDemoBar = { isDemoBarVisible = !isDemoBarVisible },
                    onNetworkBadgeClicked = { currentSection = NavigationSection.PROFILE }
                )
                HackathonDemoBar(
                    isVisible = isDemoBarVisible,
                    onRunPreset = ::handleDemoPreset,
                    onToggleVpn = {
                        NetworkSecurityService.toggleAccessForDemo(!networkState.isAuthorized)
                    }
                )
            }
        },
        bottomBar = {
            if (!isWideScreen) {
                GoogleCompassBottomNav(
                    currentSection = currentSection,
                    onSectionSelected = { currentSection = it }
                )
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isWideScreen) {
                GoogleCompassNavRail(
                    currentSection = currentSection,
                    onSectionSelected = { currentSection = it }
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                when (currentSection) {
                    NavigationSection.DASHBOARD -> {
                        DashboardScreen(
                            userProfile = userProfile,
                            growthSnapshot = growthSnapshot,
                            onNavigateToSection = { currentSection = it },
                            onAskStarter = { starterPrompt ->
                                currentSection = NavigationSection.ASK_COMPASS
                                handleSendMessage(starterPrompt)
                            }
                        )
                    }
                    NavigationSection.ASK_COMPASS -> {
                        AskCompassScreen(
                            userProfile = userProfile,
                            messages = chatMessages,
                            onSendMessage = ::handleSendMessage,
                            onAddGoalFromMentor = { newGoal ->
                                goals = goals + newGoal
                                currentSection = NavigationSection.GOALS
                            }
                        )
                    }
                    NavigationSection.GROWTH -> {
                        GrowthAssessmentScreen(
                            currentSnapshot = growthSnapshot,
                            onSnapshotUpdated = { updated ->
                                growthSnapshot = updated
                            },
                            onNavigateToPlan = {
                                currentSection = NavigationSection.THIRTY_DAY_PLAN
                            }
                        )
                    }
                    NavigationSection.THIRTY_DAY_PLAN -> {
                        ThirtyDayPlanScreen(
                            userProfile = userProfile,
                            weeks = thirtyDayWeeks,
                            onToggleActivity = { weekNumber, activityId ->
                                thirtyDayWeeks = thirtyDayWeeks.map { week ->
                                    if (week.weekNumber == weekNumber) {
                                        week.copy(
                                            activities = week.activities.map { act ->
                                                if (act.id == activityId) act.copy(isCompleted = !act.isCompleted) else act
                                            }
                                        )
                                    } else week
                                }
                            }
                        )
                    }
                    NavigationSection.CAREER_COMPASS -> {
                        CareerCompassScreen(
                            userProfile = userProfile
                        )
                    }
                    NavigationSection.COMMUNICATION_COACH -> {
                        CommunicationCoachScreen()
                    }
                    NavigationSection.GOALS -> {
                        GoalsScreen(
                            goals = goals,
                            onToggleMilestone = { goalId, milestoneId ->
                                goals = goals.map { g ->
                                    if (g.id == goalId) {
                                        g.copy(
                                            milestones = g.milestones.map { m ->
                                                if (m.id == milestoneId) m.copy(isDone = !m.isDone) else m
                                            }
                                        )
                                    } else g
                                }
                            },
                            onAddGoal = { newGoal ->
                                goals = goals + newGoal
                            }
                        )
                    }
                    NavigationSection.RESOURCES -> {
                        ResourcesScreen(
                            onAskAboutResource = { prompt ->
                                currentSection = NavigationSection.ASK_COMPASS
                                handleSendMessage(prompt)
                            }
                        )
                    }
                    NavigationSection.PROFILE -> {
                        ProfileScreen(
                            userProfile = userProfile,
                            networkState = networkState,
                            onToggleVpnAccess = { isChecked ->
                                NetworkSecurityService.toggleAccessForDemo(isChecked)
                            }
                        )
                    }
                }
            }
        }
    }
}
