package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CommunicationScenario
import com.example.model.RubricScore
import com.example.model.ScenarioFeedback
import com.example.ui.theme.*

@Composable
fun CommunicationCoachScreen(
    modifier: Modifier = Modifier
) {
    val scenarios = listOf(
        CommunicationScenario(
            id = "s1",
            title = "First Project Update to Manager",
            description = "You completed your first data pipeline validation for Field Telemetry. Give a 2-minute status update.",
            persona = "Manager",
            starterText = "Hi Sarah, so I was looking at the telemetry pipeline and basically I ran a bunch of SQL queries and found some null records in the sensor feeds, so I wrote some scripts to fix it and I think it's mostly working now.",
            contextPrompt = "Practice presenting progress, blockers, and next steps clearly."
        ),
        CommunicationScenario(
            id = "s2",
            title = "Requesting Code Review from Senior Engineer",
            description = "You created a pull request in GitLab for the Trimble Connect analytics feed. Ask Priya for a review.",
            persona = "Teammate",
            starterText = "Hey Priya, whenever you have time could you check my PR? It's just some changes to the telemetry logic.",
            contextPrompt = "Include context, PR link, testing evidence, and deadline."
        ),
        CommunicationScenario(
            id = "s3",
            title = "Explaining a Data Delay to Product Stakeholder",
            description = "An upstream ingestion service was down for 4 hours, delaying the weekly Trimble Construction report.",
            persona = "Stakeholder",
            starterText = "The report isn't ready because the other team's server crashed and we couldn't get the data in time.",
            contextPrompt = "Use BLUF format: acknowledge impact, current status, and resolution timeline."
        )
    )

    var selectedScenario by remember { mutableStateOf(scenarios.first()) }
    var selectedPersona by remember { mutableStateOf(selectedScenario.persona) }
    var draftText by remember { mutableStateOf(selectedScenario.starterText) }
    var isEvaluating by remember { mutableStateOf(false) }
    var feedbackResult by remember { mutableStateOf<ScenarioFeedback?>(null) }

    fun runEvaluation() {
        isEvaluating = true
        // Constructive mentor feedback based on user draft
        val isFirstScenario = selectedScenario.id == "s1"
        feedbackResult = ScenarioFeedback(
            summary = "Great first effort, Alex! You clearly have done the technical heavy lifting. With a few structural tweaks using Trimble's BLUF framework, this will sound confident, impactful, and executive-ready.",
            rubricScores = listOf(
                RubricScore("Clarity", "Good", "The core achievement (fixing null records in telemetry) is present, but buried in informal transition words."),
                RubricScore("Structure", "Needs Focus", "Adopt BLUF: State the outcome first (pipeline validated), followed by methodology, then the next milestone."),
                RubricScore("Confidence", "Good", "Replace hesitant phrases like 'I think it's mostly working' with concrete testing verification like 'All unit tests passed with 100% record integrity'."),
                RubricScore("Conciseness", "Good", "Trimming filler words ('so basically', 'a bunch of') will instantly elevate the professionalism."),
                RubricScore("Business Impact", "Needs Focus", "Highlight why this matters: this ensures accurate field metrics for Trimble Connected Construction customers."),
                RubricScore("Professional Tone", "Good", "Encouraging, collaborative tone. Ready for leadership syncs.")
            ),
            polishedAlternative = if (isFirstScenario) {
                "\"Hi Sarah, quick update on the Field Telemetry pipeline: validation is complete. I resolved the null record anomalies in the sensor feeds, and all integration tests are now passing with 100% data integrity. The pipeline is staged in GitLab for peer review, and I'm on track to deploy to staging by tomorrow afternoon.\""
            } else {
                "\"Hi team, bottom line up front: the weekly Construction metrics report will be published by 2:00 PM today instead of 10:00 AM. An upstream sensor feed interruption has been fully restored, and validation jobs are currently running at 85%. I will share the link the moment sync concludes.\""
            },
            mentorTips = listOf(
                "Lead with the Bottom Line Up Front (BLUF) in your first sentence.",
                "Replace 'I think' with verified test results and metrics.",
                "Always end with clear next steps or an explicit decision ask."
            )
        )
        isEvaluating = false
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Hero Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TrimbleDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(TrimbleNavy)
                                .border(1.5.dp, TrimbleCyan, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = null,
                                tint = TrimbleCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Communication Coach",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Interactive Workplace Mentoring Scenarios",
                                fontSize = 12.sp,
                                color = CompassGoldLight
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Practice presentations, updates, and cross-functional requests in a zero-risk simulator. Compass analyzes your tone, structure, conciseness, and business impact.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFCBD5E1),
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Scenario Selector
        item {
            Text(
                text = "Select Practice Scenario:",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        items(scenarios.size) { index ->
            val sc = scenarios[index]
            val isSelected = selectedScenario.id == sc.id
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) TrimbleNavy else MaterialTheme.colorScheme.surface
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) TrimbleCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        selectedScenario = sc
                        selectedPersona = sc.persona
                        draftText = sc.starterText
                        feedbackResult = null
                    }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = {
                            selectedScenario = sc
                            selectedPersona = sc.persona
                            draftText = sc.starterText
                            feedbackResult = null
                        },
                        colors = RadioButtonDefaults.colors(
                            selectedColor = TrimbleCyan,
                            unselectedColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = sc.title,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = sc.description,
                            fontSize = 11.sp,
                            color = if (isSelected) Color(0xFFCBD5E1) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Role & Persona Selector
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Simulate Listener Persona:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Manager", "Teammate", "Stakeholder").forEach { persona ->
                            val isChosen = selectedPersona == persona
                            FilterChip(
                                selected = isChosen,
                                onClick = { selectedPersona = persona },
                                label = { Text(persona) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = when (persona) {
                                            "Manager" -> Icons.Default.SupervisorAccount
                                            "Teammate" -> Icons.Default.Group
                                            else -> Icons.Default.BusinessCenter
                                        },
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Your Draft Message / Spoken Script:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = draftText,
                        onValueChange = { draftText = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 4,
                        maxLines = 6,
                        placeholder = { Text("Draft what you plan to say or write...") }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { runEvaluation() },
                        colors = ButtonDefaults.buttonColors(containerColor = TrimbleBlue),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.RateReview, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Analyze & Get Constructive Rubric Feedback")
                    }
                }
            }
        }

        // Feedback Section
        if (feedbackResult != null) {
            val fb = feedbackResult!!
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, TrimbleCyan),
                    elevation = CardDefaults.cardElevation(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = CompassGold,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Compass Feedback & Coaching Rubric",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = fb.summary,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 20.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "DETAILED RUBRIC EVALUATION:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TrimbleBlue
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        fb.rubricScores.forEach { rubric ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = rubric.category,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = if (rubric.rating == "Good") StatusStrongBg else StatusDevelopingBg
                                        ) {
                                            Text(
                                                text = rubric.rating,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (rubric.rating == "Good") StatusStrong else StatusDeveloping,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = rubric.observation,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Polished alternative recommendation
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = StatusStrongBg,
                            border = androidx.compose.foundation.BorderStroke(1.dp, StatusStrong.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = StatusStrong,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "RECOMMENDED POLISHED REVISION (BLUF):",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF065F46)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = fb.polishedAlternative,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF0F172A),
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
