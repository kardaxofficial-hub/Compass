package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.automirrored.outlined.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NavigationSection
import com.example.service.NetworkSecurityService
import com.example.ui.theme.*

@Composable
fun GoogleCompassTopBar(
    networkState: NetworkSecurityService.NetworkAccessState,
    isDemoBarVisible: Boolean,
    onToggleDemoBar: () -> Unit,
    onNetworkBadgeClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        shadowElevation = 2.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand and title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(TrimbleNavy)
                            .border(1.5.dp, TrimbleCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Explore,
                            contentDescription = "Compass Motif",
                            tint = TrimbleCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "GOOGLE COMPASS",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 0.8.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = TrimbleNavy
                            ) {
                                Text(
                                    text = "TRIMBLE • NEW HIRE EXPERIENCE",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TrimbleCyan,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Your AI Mentor for the Journey Ahead",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Right actions: Secure Access chip and Demo toggle
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Secure Access Chip
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (networkState.isAuthorized) StatusStrongBg else Color(0xFFFFEBEE),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (networkState.isAuthorized) StatusStrong else Color(0xFFEF4444)
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onNetworkBadgeClicked() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (networkState.isAuthorized) StatusStrong else Color(0xFFEF4444))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (networkState.isAuthorized) "Trimble Access: Connected" else "Access: Blocked",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (networkState.isAuthorized) Color(0xFF065F46) else Color(0xFF991B1B)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Demo Mode toggle button
                    FilledTonalButton(
                        onClick = onToggleDemoBar,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (isDemoBarVisible) CompassGold.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Demo Mode",
                            tint = CompassGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Demo",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDemoBarVisible) CompassGold else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HackathonDemoBar(
    isVisible: Boolean,
    onRunPreset: (String) -> Unit,
    onToggleVpn: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(visible = isVisible) {
        Surface(
            modifier = modifier.fillMaxWidth(),
            color = TrimbleDark,
            contentColor = Color.White
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Demo presets",
                        tint = CompassGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "HACKATHON 1-CLICK DEMO PATHS:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CompassGoldLight,
                        letterSpacing = 0.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DemoChip(label = "👋 1. Welcome Alex (Overwhelmed)", onClick = { onRunPreset("welcome") })
                    DemoChip(label = "📚 2. RAG Citation (New Hire Guide)", onClick = { onRunPreset("rag_cite") })
                    DemoChip(label = "📊 3. Growth Assessment Snapshot", onClick = { onRunPreset("assessment") })
                    DemoChip(label = "🗓️ 4. 30-Day Personalized Plan", onClick = { onRunPreset("plan") })
                    DemoChip(label = "🧭 5. Career Compass Roadmap", onClick = { onRunPreset("career") })
                    DemoChip(label = "🎤 6. Comm Coach (Update)", onClick = { onRunPreset("comm_coach") })
                    DemoChip(label = "🎯 7. Goal Setting", onClick = { onRunPreset("goals") })
                    DemoChip(label = "🛡️ 8. Toggle VPN Access Check", onClick = onToggleVpn, isWarning = true)
                }
            }
        }
    }
}

@Composable
private fun DemoChip(
    label: String,
    onClick: () -> Unit,
    isWarning: Boolean = false
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isWarning) Color(0xFF3B1818) else Color(0xFF1E293B),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isWarning) Color(0xFFEF4444) else TrimbleCyan.copy(alpha = 0.5f)
        ),
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = if (isWarning) Color(0xFFFCA5A5) else Color(0xFFE2E8F0),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun GoogleCompassBottomNav(
    currentSection: NavigationSection,
    onSectionSelected: (NavigationSection) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
    ) {
        val navItems = listOf(
            NavigationSection.DASHBOARD to (Icons.Default.Dashboard to Icons.Outlined.Dashboard),
            NavigationSection.ASK_COMPASS to (Icons.AutoMirrored.Filled.Chat to Icons.AutoMirrored.Outlined.Chat),
            NavigationSection.GROWTH to (Icons.AutoMirrored.Filled.TrendingUp to Icons.AutoMirrored.Outlined.TrendingUp),
            NavigationSection.THIRTY_DAY_PLAN to (Icons.Default.CalendarToday to Icons.Outlined.CalendarToday),
            NavigationSection.CAREER_COMPASS to (Icons.Default.Explore to Icons.Outlined.Explore),
            NavigationSection.COMMUNICATION_COACH to (Icons.Default.RecordVoiceOver to Icons.Outlined.RecordVoiceOver),
            NavigationSection.GOALS to (Icons.Default.Flag to Icons.Outlined.Flag),
            NavigationSection.RESOURCES to (Icons.Default.Folder to Icons.Outlined.Folder),
            NavigationSection.PROFILE to (Icons.Default.Person to Icons.Outlined.Person)
        )

        // Show prominent primary items in bottom bar, others accessible via dashboard or horizontal scroll
        navItems.forEach { (section, iconPair) ->
            val isSelected = currentSection == section
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSectionSelected(section) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) iconPair.first else iconPair.second,
                        contentDescription = section.label
                    )
                },
                label = {
                    Text(
                        text = section.label,
                        maxLines = 1,
                        fontSize = 10.sp,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = TrimbleCyan,
                    selectedTextColor = TrimbleCyan,
                    indicatorColor = TrimbleNavy
                )
            )
        }
    }
}

@Composable
fun GoogleCompassNavRail(
    currentSection: NavigationSection,
    onSectionSelected: (NavigationSection) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationRail(
        modifier = modifier,
        containerColor = TrimbleDark,
        contentColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .padding(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val navItems = listOf(
                NavigationSection.DASHBOARD to Icons.Default.Dashboard,
                NavigationSection.ASK_COMPASS to Icons.AutoMirrored.Filled.Chat,
                NavigationSection.GROWTH to Icons.AutoMirrored.Filled.TrendingUp,
                NavigationSection.THIRTY_DAY_PLAN to Icons.Default.CalendarToday,
                NavigationSection.CAREER_COMPASS to Icons.Default.Explore,
                NavigationSection.COMMUNICATION_COACH to Icons.Default.RecordVoiceOver,
                NavigationSection.GOALS to Icons.Default.Flag,
                NavigationSection.RESOURCES to Icons.Default.Folder,
                NavigationSection.PROFILE to Icons.Default.Person
            )

            navItems.forEach { (section, icon) ->
                val isSelected = currentSection == section
                NavigationRailItem(
                    selected = isSelected,
                    onClick = { onSectionSelected(section) },
                    icon = {
                        Icon(
                            imageVector = icon,
                            contentDescription = section.label,
                            tint = if (isSelected) TrimbleCyan else Color(0xFF94A3B8)
                        )
                    },
                    label = {
                        Text(
                            text = section.label,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = if (isSelected) TrimbleCyan else Color(0xFF94A3B8)
                        )
                    },
                    colors = NavigationRailItemDefaults.colors(
                        indicatorColor = TrimbleNavy
                    )
                )
            }
        }
    }
}
