package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GrowthSnapshot
import com.example.model.GrowthStatus
import com.example.model.NavigationSection
import com.example.ui.components.GrowthStatusBadge
import com.example.ui.theme.*

data class AssessmentQuestion(
    val id: String,
    val category: String,
    val question: String,
    val options: List<String>,
    var selectedOptionIndex: Int = -1
)

@Composable
fun GrowthAssessmentScreen(
    currentSnapshot: GrowthSnapshot,
    onSnapshotUpdated: (GrowthSnapshot) -> Unit,
    onNavigateToPlan: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showQuiz by remember { mutableStateOf(false) }

    val defaultQuestions = remember {
        mutableStateListOf(
            AssessmentQuestion(
                "q1",
                "Communication",
                "How comfortable are you explaining your work to someone outside your team?",
                listOf("Not yet comfortable", "Somewhat comfortable", "Comfortable", "Very comfortable"),
                selectedOptionIndex = 1
            ),
            AssessmentQuestion(
                "q2",
                "Trimble Knowledge",
                "How familiar are you with Trimble's 4 business units and 1978 origin?",
                listOf("Just starting out", "Familiar with my division", "Good cross-company understanding", "Deep organizational literacy"),
                selectedOptionIndex = 0
            ),
            AssessmentQuestion(
                "q3",
                "Technical Skills",
                "How comfortable are you with Trimble data tools (Snowflake, SQL, Python style guide)?",
                listOf("Need fundamental tutorials", "Comfortable with basic scripts", "Confident building pipelines", "Expert in production standards"),
                selectedOptionIndex = 2
            ),
            AssessmentQuestion(
                "q4",
                "Product Knowledge",
                "Can you articulate how Trimble Connect integrates hardware and cloud data?",
                listOf("Exploring basics", "Understand high level", "Can demo workflows", "Can architect integrations"),
                selectedOptionIndex = 0
            ),
            AssessmentQuestion(
                "q5",
                "Collaboration",
                "How confident are you seeking async code reviews or reaching out across squads?",
                listOf("Hesitant to reach out", "Ask team buddy only", "Actively seek reviews in Slack", "Lead collaborative reviews"),
                selectedOptionIndex = 1
            ),
            AssessmentQuestion(
                "q6",
                "Career Clarity",
                "Do you have a clear vision of skills needed to progress to Senior Analyst?",
                listOf("Still exploring options", "Vague milestones in mind", "Specific roadmap drafted", "Actioning concrete milestones"),
                selectedOptionIndex = 1
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Top Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TrimbleDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Personal Growth Assessment",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Self-assess your comfort across key onboarding pillars to get tailored growth priorities and recommendations.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFCBD5E1)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Non-performance review disclaimer
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF1E293B),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CompassGold.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = CompassGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Your Growth Snapshot is for personal development and is not an employee performance evaluation.",
                                fontSize = 11.sp,
                                color = CompassGoldLight,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Action to retake or toggle assessment questionnaire
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (showQuiz) "Assessment Questions (6/6)" else "Your Personal Growth Snapshot",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                TextButton(onClick = { showQuiz = !showQuiz }) {
                    Icon(
                        imageVector = if (showQuiz) Icons.Default.Check else Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (showQuiz) "Show Snapshot Matrix" else "Retake Assessment")
                }
            }
        }

        if (showQuiz) {
            // Interactive Question Cards
            items(defaultQuestions.size) { index ->
                val q = defaultQuestions[index]
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "CATEGORY: ${q.category.uppercase()}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TrimbleBlue
                            )
                            Text(
                                text = "Question ${index + 1} of 6",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = q.question,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        q.options.forEachIndexed { optIndex, optionText ->
                            val isSelected = q.selectedOptionIndex == optIndex
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) TrimbleNavy else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, TrimbleCyan) else null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        defaultQuestions[index] = q.copy(selectedOptionIndex = optIndex)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = {
                                            defaultQuestions[index] = q.copy(selectedOptionIndex = optIndex)
                                        },
                                        colors = RadioButtonDefaults.colors(
                                            selectedColor = TrimbleCyan,
                                            unselectedColor = MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = optionText,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        showQuiz = false
                        // Calculate fresh snapshot based on options
                        val newSnapshot = GrowthSnapshot(
                            trimbleKnowledge = if (defaultQuestions[1].selectedOptionIndex >= 2) GrowthStatus.STRONG else if (defaultQuestions[1].selectedOptionIndex == 1) GrowthStatus.DEVELOPING else GrowthStatus.EXPLORE,
                            productKnowledge = if (defaultQuestions[3].selectedOptionIndex >= 2) GrowthStatus.STRONG else if (defaultQuestions[3].selectedOptionIndex == 1) GrowthStatus.DEVELOPING else GrowthStatus.EXPLORE,
                            technicalSkills = if (defaultQuestions[2].selectedOptionIndex >= 2) GrowthStatus.STRONG else GrowthStatus.DEVELOPING,
                            communication = if (defaultQuestions[0].selectedOptionIndex >= 2) GrowthStatus.STRONG else GrowthStatus.DEVELOPING,
                            collaboration = if (defaultQuestions[4].selectedOptionIndex >= 2) GrowthStatus.STRONG else GrowthStatus.DEVELOPING,
                            careerClarity = if (defaultQuestions[5].selectedOptionIndex >= 2) GrowthStatus.STRONG else GrowthStatus.EXPLORE
                        )
                        onSnapshotUpdated(newSnapshot)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = TrimbleBlue)
                ) {
                    Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save & Update Growth Snapshot")
                }
            }
        } else {
            // Display Results Matrix
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        GrowthAreaRow("Trimble Knowledge", currentSnapshot.trimbleKnowledge, "Understanding company history, 4 divisions, and culture")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        GrowthAreaRow("Product Knowledge", GrowthStatus.EXPLORE, "Trimble Connect architecture and field-to-office telemetry")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        GrowthAreaRow("Technical Skills", currentSnapshot.technicalSkills, "Snowflake queries, Python modeling, GitLab analytics reviews")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        GrowthAreaRow("Communication", currentSnapshot.communication, "Executive BLUF formatting, sprint demos, and slide design")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        GrowthAreaRow("Collaboration", currentSnapshot.collaboration, "Seeking cross-functional feedback and buddy syncs")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        GrowthAreaRow("Career Clarity", currentSnapshot.careerClarity, "Long-term trajectory toward Senior Data Analyst")
                    }
                }
            }

            // Top 2-3 Recommended Development Priorities
            item {
                Text(
                    text = "Recommended Development Priorities",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            items(currentSnapshot.topPriorities.size) { index ->
                val priority = currentSnapshot.topPriorities[index]
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CompassGold.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(CompassGoldLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${index + 1}",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF78350F),
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = priority,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Mapped directly into your 30-Day Learning Path",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Go",
                            tint = TrimbleBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            item {
                Button(
                    onClick = onNavigateToPlan,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = TrimbleBlue)
                ) {
                    Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("View Your Tailored 30-Day Plan")
                }
            }
        }
    }
}

@Composable
private fun GrowthAreaRow(
    title: String,
    status: GrowthStatus,
    subtitle: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        GrowthStatusBadge(status = status)
    }
}
