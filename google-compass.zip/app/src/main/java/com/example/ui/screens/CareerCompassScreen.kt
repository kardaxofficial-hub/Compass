package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingFlat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CareerRoadmapStep
import com.example.model.UserProfile
import com.example.ui.theme.*

@Composable
fun CareerCompassScreen(
    userProfile: UserProfile,
    modifier: Modifier = Modifier
) {
    var currentRole by remember { mutableStateOf(userProfile.role) }
    var targetRole by remember { mutableStateOf(userProfile.careerGoal) }
    var currentSkills by remember { mutableStateOf("SQL, Basic Python, Tableau, Excel, Git") }

    val roadmapSteps = remember {
        listOf(
            CareerRoadmapStep(
                phase = "Phase 1: Foundation",
                title = "Current State Mastery",
                description = "Master Trimble's core analytics telemetry pipelines and Snowflake data warehouse schemas.",
                keySkills = listOf("Advanced SQL Window Functions", "Snowflake Telemetry Modeling", "Trimble Analytics Style Guide"),
                experiences = listOf("Shadow 2 production pipeline releases", "Complete first peer-reviewed analytics PR in GitLab"),
                resources = listOf("Trimble Learn: Snowflake Foundations", "Trimble GitLab Analytics Style Guide (p. 5)")
            ),
            CareerRoadmapStep(
                phase = "Phase 2: Expansion",
                title = "Skills to Develop",
                description = "Build autonomous end-to-end data pipelines and learn IoT telemetry streaming from Trimble Connect.",
                keySkills = listOf("Python ETL Orchestration", "dbt data modeling", "Trimble Connect REST APIs"),
                experiences = listOf("Own 1 recurring business unit analytics report end-to-end", "Present quarterly metrics to product managers"),
                resources = listOf("Coursera Enterprise: Data Engineering Specialization", "Trimble Connect API Documentation")
            ),
            CareerRoadmapStep(
                phase = "Phase 3: Impact",
                title = "Experiences to Gain",
                description = "Drive cross-functional analytical initiatives and mentor incoming fresher cohorts in Trimble ECPN.",
                keySkills = listOf("Executive BLUF Communication", "System Modularity", "Data Governance & Compliance"),
                experiences = listOf("Lead a cross-business-unit analytics sprint", "Facilitate a technical brown-bag session for ECPN"),
                resources = listOf("Trimble Workplace Communication Guide (p. 15)", "Mentoring Circles Program")
            ),
            CareerRoadmapStep(
                phase = "Phase 4: Capstone",
                title = "Target Milestones → Senior Role",
                description = "Demonstrate sustained high-quality analytical delivery, strategic alignment, and technical mentorship.",
                keySkills = listOf("Technical Roadmap Planning", "Architectural Decision Records", "Cross-Squad Leadership"),
                experiences = listOf("Sponsor an onboarding fresher", "Deliver an executive-level analytics strategy deck"),
                resources = listOf("Trimble Mentorship & Growth Handbook (p. 21)")
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Hero Header
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TrimbleDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(TrimbleNavy)
                                .border(1.5.dp, CompassGold, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Explore,
                                contentDescription = null,
                                tint = CompassGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Career Compass",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Your Personalized Development Roadmap",
                                fontSize = 12.sp,
                                color = TrimbleCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Mandatory promotion disclaimer
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF1E293B),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Career recommendations are provided as guidance for personal development and are not guaranteed promotion criteria.",
                                fontSize = 11.sp,
                                color = Color(0xFFE2E8F0)
                            )
                        }
                    }
                }
            }
        }

        // Editable Role / Goal Parameters
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Development Trajectory Parameters",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = currentRole,
                        onValueChange = { currentRole = it },
                        label = { Text("Current Role") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = targetRole,
                        onValueChange = { targetRole = it },
                        label = { Text("Desired Future Goal") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = currentSkills,
                        onValueChange = { currentSkills = it },
                        label = { Text("Current Skills") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Roadmap Stepper
        item {
            Text(
                text = "Conceptual Growth Roadmap",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        items(roadmapSteps) { step ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = TrimbleNavy
                        ) {
                            Text(
                                text = step.phase,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TrimbleCyan,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.TrendingFlat,
                            contentDescription = null,
                            tint = TrimbleBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = step.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = step.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "SKILLS TO DEVELOP:",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        step.keySkills.forEach { skill ->
                            SuggestionChip(
                                onClick = {},
                                label = { Text(skill, fontSize = 10.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "EXPERIENCES TO GAIN:",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB45309)
                    )
                    step.experiences.forEach { exp ->
                        Text(
                            text = "• $exp",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "INTERNAL LEARNING RESOURCES:",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TrimbleBlue
                    )
                    step.resources.forEach { res ->
                        Text(
                            text = "📖 $res",
                            fontSize = 11.sp,
                            color = TrimbleBlue,
                            modifier = Modifier.padding(vertical = 1.dp)
                        )
                    }
                }
            }
        }
    }
}
