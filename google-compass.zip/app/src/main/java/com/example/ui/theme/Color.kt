package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Trimble Enterprise & Google Compass Brand Colors
val TrimbleNavy = Color(0xFF001E3D)
val TrimbleDark = Color(0xFF0A192F)
val TrimbleBlue = Color(0xFF005F9E)
val TrimbleCyan = Color(0xFF00A3FF)
val CompassGold = Color(0xFFF59E0B)
val CompassGoldLight = Color(0xFFFDE68A)

// Status colors
val StatusStrong = Color(0xFF10B981)       // Green
val StatusStrongBg = Color(0xFFECFDF5)
val StatusDeveloping = Color(0xFFF59E0B)   // Amber
val StatusDevelopingBg = Color(0xFFFFFBEB)
val StatusExplore = Color(0xFF6366F1)      // Indigo/Purple
val StatusExploreBg = Color(0xFFEEF2FF)

// UI Neutrals (Light)
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OutlineLight = Color(0xFFCBD5E1)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)

// UI Neutrals (Dark)
val BackgroundDark = Color(0xFF0B132B)
val SurfaceDark = Color(0xFF111D3D)
val SurfaceVariantDark = Color(0xFF1C2C55)
val OutlineDark = Color(0xFF2E4374)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)

