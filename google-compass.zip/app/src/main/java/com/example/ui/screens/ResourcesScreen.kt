package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ResourceItem
import com.example.ui.theme.*

@Composable
fun ResourcesScreen(
    onAskAboutResource: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val categories = listOf("All", "New Hire", "Learning", "Mentorship", "Career", "Communication", "Employee Networks", "Recognition", "Technical")
    var selectedCategory by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }

    val allResources = remember {
        listOf(
            ResourceItem(
                id = "r1",
                title = "Trimble Learn (Cyber & Compliance Modules)",
                category = "New Hire",
                description = "Mandatory company onboarding modules including data privacy, security compliance, and Trimble code of conduct.",
                documentReference = "Trimble Global New Hire Orientation — Page 12",
                whyItMattersForFreshers = "Required to be completed within first 14 days to obtain full production system credentials.",
                recommendedAction = "Verify your completion status with your People Manager."
            ),
            ResourceItem(
                id = "r2",
                title = "Trimble People Portal (Growth & Mentorship Hub)",
                category = "Mentorship",
                description = "Internal portal to request a 1:1 cross-functional mentor, join Mentoring Circles, and log development goals.",
                documentReference = "Trimble Mentorship & Growth Handbook — Page 6",
                whyItMattersForFreshers = "Eligible for matching after Week 2. Provides guidance outside your reporting line.",
                recommendedAction = "Submit your profile and top 3 learning interests."
            ),
            ResourceItem(
                id = "r3",
                title = "Early Career Professionals Network (ECPN)",
                category = "Employee Networks",
                description = "Trimble's employee resource group uniting new graduates and junior engineers across global offices.",
                documentReference = "Trimble Employee Networks Guide — Page 3",
                whyItMattersForFreshers = "Build peer connections, participate in fresher hackathons, and attend executive AMAs.",
                recommendedAction = "Join the #ecpn-global Slack channel and attend the monthly meetup."
            ),
            ResourceItem(
                id = "r4",
                title = "Trimble Analytics GitLab & Python Style Guide",
                category = "Technical",
                description = "Authoritative standards for data modeling, Snowflake query optimization, and peer review conventions.",
                documentReference = "Trimble Engineering & Analytics Standards — Page 5",
                whyItMattersForFreshers = "Ensures all code written meets enterprise quality and passes first-round peer reviews.",
                recommendedAction = "Bookmark repo in GitLab and review the SQL linting checklist."
            ),
            ResourceItem(
                id = "r5",
                title = "Trimble University, Coursera & O'Reilly Enterprise",
                category = "Learning",
                description = "Complimentary professional learning library with 4 hours/month of protected on-the-clock learning time.",
                documentReference = "Trimble Employee Networks & Development Programs — Page 9",
                whyItMattersForFreshers = "Upskill in advanced Snowflake, dbt, and cloud telemetry without out-of-pocket costs.",
                recommendedAction = "Activate your enterprise SSO account on Coursera."
            ),
            ResourceItem(
                id = "r6",
                title = "BLUF Communication Framework & Sprint Demo Templates",
                category = "Communication",
                description = "Guidelines for structuring asynchronous project updates, email briefs, and sprint stakeholder reviews.",
                documentReference = "Trimble Workplace Communication Guide — Page 7",
                whyItMattersForFreshers = "Helps freshers communicate like senior contributors by leading with business impact.",
                recommendedAction = "Practice in Google Compass Communication Coach."
            ),
            ResourceItem(
                id = "r7",
                title = "Trimble Kudos (Peer-to-Peer Recognition)",
                category = "Recognition",
                description = "Internal recognition tool for celebrating teammates who exemplify core Trimble values.",
                documentReference = "Trimble Employee Networks & Development Programs — Page 16",
                whyItMattersForFreshers = "Recognize onboarding buddies and senior mentors who supported your ramp-up.",
                recommendedAction = "Send your first Kudos to your onboarding buddy."
            ),
            ResourceItem(
                id = "r8",
                title = "Trimble Connect Cloud Developer Architecture",
                category = "Career",
                description = "High-level architectural documentation on Trimble's connected data environment.",
                documentReference = "Trimble Global New Hire Orientation — Page 18",
                whyItMattersForFreshers = "Crucial for understanding how hardware sensors feed data into cloud analytics.",
                recommendedAction = "Read the Connected Construction overview on Confluence."
            )
        )
    }

    val filteredResources = allResources.filter { item ->
        val matchesCategory = selectedCategory == "All" || item.category.equals(selectedCategory, ignoreCase = true)
        val matchesQuery = searchQuery.isBlank() ||
                item.title.contains(searchQuery, ignoreCase = true) ||
                item.description.contains(searchQuery, ignoreCase = true) ||
                item.category.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesQuery
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Hero Header
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TrimbleDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Internal Resource Discovery",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Authoritative Trimble internal platforms, tools, and networks",
                        fontSize = 12.sp,
                        color = TrimbleCyan
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search internal resources or tools...", color = Color(0xFF94A3B8)) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TrimbleCyan)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = Color.White)
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TrimbleCyan,
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        }

        // Category Filter Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    val isSelected = selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TrimbleNavy,
                            selectedLabelColor = TrimbleCyan
                        )
                    )
                }
            }
        }

        // Resources List
        items(filteredResources, key = { it.id }) { item ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = TrimbleNavy
                        ) {
                            Text(
                                text = item.category.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TrimbleCyan,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        TextButton(
                            onClick = {
                                onAskAboutResource("Tell me more about ${item.title} and what I should do next.")
                            }
                        ) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(14.dp), tint = TrimbleBlue)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Ask Compass", fontSize = 11.sp, color = TrimbleBlue)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = item.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "VERIFIED INTERNAL SOURCE:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TrimbleBlue
                            )
                            Text(
                                text = "📄 ${item.documentReference}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "WHY IT MATTERS FOR FRESHERS:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB45309)
                            )
                            Text(
                                text = item.whyItMattersForFreshers,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}
