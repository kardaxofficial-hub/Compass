package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Goal
import com.example.model.Milestone
import com.example.ui.theme.*
import java.util.UUID

@Composable
fun GoalsScreen(
    goals: List<Goal>,
    onToggleMilestone: (goalId: String, milestoneId: String) -> Unit,
    onAddGoal: (Goal) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCreateDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Hero Header
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TrimbleDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Personal Development Goals",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Track intentions, milestones, and mentor suggestions",
                                fontSize = 12.sp,
                                color = TrimbleCyan
                            )
                        }

                        FloatingActionButton(
                            onClick = { showCreateDialog = true },
                            containerColor = TrimbleCyan,
                            contentColor = TrimbleNavy,
                            modifier = Modifier.size(42.dp),
                            shape = CircleShape
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Goal")
                        }
                    }
                }
            }
        }

        // List of Goals
        items(goals, key = { it.id }) { goal ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = TrimbleNavy
                        ) {
                            Text(
                                text = goal.category.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TrimbleCyan,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Text(
                            text = "Target: ${goal.targetDays} days",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = goal.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = goal.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Progress Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Milestones Progress",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${(goal.progress * 100).toInt()}%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TrimbleBlue
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { goal.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (goal.progress == 1f) StatusStrong else TrimbleBlue,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Milestones Checklist
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        goal.milestones.forEach { milestone ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Checkbox(
                                    checked = milestone.isDone,
                                    onCheckedChange = {
                                        onToggleMilestone(goal.id, milestone.id)
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = StatusStrong)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = milestone.title,
                                    fontSize = 12.sp,
                                    color = if (milestone.isDone) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateGoalDialog(
            onDismiss = { showCreateDialog = false },
            onSave = { newGoal ->
                onAddGoal(newGoal)
                showCreateDialog = false
            }
        )
    }
}

@Composable
private fun CreateGoalDialog(
    onDismiss: () -> Unit,
    onSave: (Goal) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Communication") }
    var durationDays by remember { mutableStateOf("60") }
    var milestone1 by remember { mutableStateOf("Complete communication learning module") }
    var milestone2 by remember { mutableStateOf("Practice presentation with mentor") }
    var milestone3 by remember { mutableStateOf("Present in sprint meeting and request feedback") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create New Development Goal") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Goal Title") },
                    placeholder = { Text("e.g. Improve stakeholder communication") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = durationDays,
                    onValueChange = { durationDays = it },
                    label = { Text("Target Duration (Days)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Key Milestones:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                OutlinedTextField(
                    value = milestone1,
                    onValueChange = { milestone1 = it },
                    label = { Text("Milestone 1") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = milestone2,
                    onValueChange = { milestone2 = it },
                    label = { Text("Milestone 2") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = milestone3,
                    onValueChange = { milestone3 = it },
                    label = { Text("Milestone 3") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val days = durationDays.toIntOrNull() ?: 30
                        val goal = Goal(
                            id = UUID.randomUUID().toString(),
                            title = title,
                            description = description.ifBlank { "Personalized Trimble onboarding goal" },
                            category = category,
                            targetDays = days,
                            milestones = listOf(
                                Milestone(UUID.randomUUID().toString(), milestone1),
                                Milestone(UUID.randomUUID().toString(), milestone2),
                                Milestone(UUID.randomUUID().toString(), milestone3)
                            )
                        )
                        onSave(goal)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TrimbleBlue)
            ) {
                Text("Create Goal")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
