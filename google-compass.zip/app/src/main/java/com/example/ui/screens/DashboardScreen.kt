package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GrowthSnapshot
import com.example.model.GrowthStatus
import com.example.model.NavigationSection
import com.example.model.UserProfile
import com.example.ui.components.GrowthStatusBadge
import com.example.ui.theme.*

data class NextStepItem(
    val id: String,
    val title: String,
    val targetSection: NavigationSection,
    val subtitle: String,
    val isCompleted: Boolean = false
)

@Composable
fun DashboardScreen(
    userProfile: UserProfile,
    growthSnapshot: GrowthSnapshot,
    onNavigateToSection: (NavigationSection) -> Unit,
    onAskStarter: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var nextSteps by remember {
        mutableStateOf(
            listOf(
                NextStepItem("1", "Complete your Trimble orientation", NavigationSection.THIRTY_DAY_PLAN, "Global New Hire modules & cyber compliance", true),
                NextStepItem("2", "Explore your product area", NavigationSection.ASK_COMPASS, "Connected Construction & Trimble Connect architecture", false),
                NextStepItem("3", "Practice your first team introduction", NavigationSection.COMMUNICATION_COACH, "Simulate team standup / manager update", false),
                NextStepItem("4", "Connect with a mentor", NavigationSection.ASK_COMPASS, "Submit 1:1 mentorship request on People Portal", false),
                NextStepItem("5", "Set your first 30-day goal", NavigationSection.GOALS, "Define measurable technical & onboarding milestones", false)
            )
        )
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen_container")
    ) {
        val isWide = maxWidth >= 760.dp

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = if (isWide) 24.dp else 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // Welcome Header
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = TrimbleDark),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dashboard_header_card")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(if (isWide) 24.dp else 20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Good morning, Alex 👋",
                                    style = if (isWide) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.testTag("dashboard_welcome_header")
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Let's make your journey at Trimble a little easier.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFFCBD5E1)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFF1E293B)
                                ) {
                                    Text(
                                        text = "Day ${userProfile.daysAtTrimble} at Trimble • ${userProfile.role}",
                                        fontSize = 11.sp,
                                        color = TrimbleCyan,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(if (isWide) 64.dp else 54.dp)
                                .clip(CircleShape)
                                .background(TrimbleNavy)
                                .border(2.dp, CompassGold, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Explore,
                                contentDescription = "Compass",
                                tint = CompassGold,
                                modifier = Modifier.size(if (isWide) 38.dp else 32.dp)
                            )
                        }
                    }
                }
            }

            // Core Differentiator Callout
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = TrimbleNavy.copy(alpha = 0.08f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TrimbleCyan.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = "Philosophy",
                            tint = CompassGold,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "\"From information to intention.\"",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Google Compass explains what things mean, why they matter, and what you should do next.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Adaptive Section: On wide screens, display Snapshot and Next Steps side-by-side or stacked cleanly
            if (isWide) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        // Left Column: Personal Growth Snapshot
                        Column(modifier = Modifier.weight(1.1f)) {
                            PersonalGrowthSnapshotSection(
                                growthSnapshot = growthSnapshot,
                                onNavigateToAssessment = { onNavigateToSection(NavigationSection.GROWTH) }
                            )
                        }

                        // Right Column: Your Recommended Next Steps
                        Column(modifier = Modifier.weight(0.9f)) {
                            RecommendedNextStepsSection(
                                nextSteps = nextSteps,
                                onToggleStep = { id, checked ->
                                    nextSteps = nextSteps.map {
                                        if (it.id == id) it.copy(isCompleted = checked) else it
                                    }
                                },
                                onStepClicked = { item ->
                                    onNavigateToSection(item.targetSection)
                                }
                            )
                        }
                    }
                }
            } else {
                // Mobile Portrait: Stacked
                item {
                    PersonalGrowthSnapshotSection(
                        growthSnapshot = growthSnapshot,
                        onNavigateToAssessment = { onNavigateToSection(NavigationSection.GROWTH) }
                    )
                }

                item {
                    RecommendedNextStepsSection(
                        nextSteps = nextSteps,
                        onToggleStep = { id, checked ->
                            nextSteps = nextSteps.map {
                                if (it.id == id) it.copy(isCompleted = checked) else it
                            }
                        },
                        onStepClicked = { item ->
                            onNavigateToSection(item.targetSection)
                        }
                    )
                }
            }

            // Key Mentorship Features Shortcut Grid
            item {
                Text(
                    text = "Key Mentorship Features",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FeatureShortcutCard(
                        title = "Ask Compass",
                        description = "Enterprise AI Mentor with RAG Document Citations",
                        icon = Icons.AutoMirrored.Filled.Chat,
                        iconTint = TrimbleCyan,
                        onClick = { onNavigateToSection(NavigationSection.ASK_COMPASS) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("shortcut_ask_compass")
                    )
                    FeatureShortcutCard(
                        title = "Comm Coach",
                        description = "Roleplay project updates & get instant rubric feedback",
                        icon = Icons.Default.RecordVoiceOver,
                        iconTint = CompassGold,
                        onClick = { onNavigateToSection(NavigationSection.COMMUNICATION_COACH) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("shortcut_comm_coach")
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FeatureShortcutCard(
                        title = "30-Day Plan",
                        description = "Structured week-by-week onboarding milestones",
                        icon = Icons.Default.CalendarToday,
                        iconTint = StatusStrong,
                        onClick = { onNavigateToSection(NavigationSection.THIRTY_DAY_PLAN) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("shortcut_30_day_plan")
                    )
                    FeatureShortcutCard(
                        title = "Career Compass",
                        description = "From Fresher to Senior Data Analyst roadmap",
                        icon = Icons.Default.Explore,
                        iconTint = TrimbleBlue,
                        onClick = { onNavigateToSection(NavigationSection.CAREER_COMPASS) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("shortcut_career_compass")
                    )
                }
            }
        }
    }
}

@Composable
private fun PersonalGrowthSnapshotSection(
    growthSnapshot: GrowthSnapshot,
    onNavigateToAssessment: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("personal_growth_snapshot_section")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Insights,
                    contentDescription = null,
                    tint = TrimbleBlue,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Personal Growth Snapshot",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            TextButton(
                onClick = onNavigateToAssessment,
                modifier = Modifier.testTag("btn_view_assessment")
            ) {
                Text("View Assessment", fontSize = 12.sp, color = TrimbleBlue)
            }
        }

        // Disclaimer (Mandatory Requirement 5)
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Disclaimer",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Your Growth Snapshot is for personal development and is not an employee performance evaluation.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // The four required metrics:
        // 1. Trimble Knowledge
        // 2. Role Readiness
        // 3. Communication
        // 4. Career Clarity
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SnapshotMetricCard(
                title = "Trimble Knowledge",
                status = growthSnapshot.trimbleKnowledge,
                icon = Icons.Default.CorporateFare,
                tag = "metric_trimble_knowledge",
                modifier = Modifier.weight(1f)
            )
            SnapshotMetricCard(
                title = "Role Readiness",
                status = growthSnapshot.roleReadiness,
                icon = Icons.Default.Handyman,
                tag = "metric_role_readiness",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SnapshotMetricCard(
                title = "Communication",
                status = growthSnapshot.communication,
                icon = Icons.Default.ChatBubbleOutline,
                tag = "metric_communication",
                modifier = Modifier.weight(1f)
            )
            SnapshotMetricCard(
                title = "Career Clarity",
                status = growthSnapshot.careerClarity,
                icon = Icons.AutoMirrored.Filled.TrendingUp,
                tag = "metric_career_clarity",
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun RecommendedNextStepsSection(
    nextSteps: List<NextStepItem>,
    onToggleStep: (String, Boolean) -> Unit,
    onStepClicked: (NextStepItem) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("recommended_next_steps_section")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircleOutline,
                    contentDescription = null,
                    tint = StatusStrong,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Your Recommended Next Steps",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Text(
                text = "${nextSteps.count { it.isCompleted }} of ${nextSteps.size} done",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                nextSteps.forEachIndexed { index, item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onStepClicked(item) }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                            .testTag("next_step_item_${item.id}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = item.isCompleted,
                            onCheckedChange = { checked ->
                                onToggleStep(item.id, checked)
                            },
                            colors = CheckboxDefaults.colors(checkedColor = StatusStrong),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = if (item.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = item.subtitle,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Go",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    if (index < nextSteps.size - 1) {
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 14.dp),
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SnapshotMetricCard(
    title: String,
    status: GrowthStatus,
    icon: ImageVector,
    tag: String,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
        modifier = modifier.testTag(tag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = TrimbleBlue,
                        modifier = Modifier.size(18.dp)
                    )
                }
                GrowthStatusBadge(status = status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun FeatureShortcutCard(
    title: String,
    description: String,
    icon: ImageVector,
    iconTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
    }
}
