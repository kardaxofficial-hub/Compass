package com.example.model

enum class NavigationSection(val label: String, val badge: String = "") {
    DASHBOARD("Dashboard"),
    ASK_COMPASS("AI Mentor", "RAG"),
    GROWTH("My Growth"),
    THIRTY_DAY_PLAN("30-Day Plan"),
    CAREER_COMPASS("Career Compass"),
    COMMUNICATION_COACH("Comm Coach"),
    GOALS("Goals"),
    RESOURCES("Resources"),
    PROFILE("Profile")
}

data class UserProfile(
    val name: String = "Alex",
    val role: String = "Data Analyst",
    val experienceLevel: String = "Fresher / New Graduate",
    val businessUnit: String = "Geospatial & Field Solutions",
    val team: String = "Field Telemetry & Analytics",
    val manager: String = "Sarah Jenkins (Director of Analytics)",
    val mentor: String = "Priya Sharma (Staff Data Engineer)",
    val daysAtTrimble: Int = 14,
    val interests: List<String> = listOf("Data Engineering", "AI & Machine Learning", "Executive Communication"),
    val careerGoal: String = "Become a Senior Data Analyst"
)

enum class GrowthStatus(val label: String) {
    STRONG("Strong"),
    DEVELOPING("Developing"),
    EXPLORE("Explore")
}

data class GrowthSnapshot(
    val trimbleKnowledge: GrowthStatus = GrowthStatus.EXPLORE,
    val productKnowledge: GrowthStatus = GrowthStatus.EXPLORE,
    val roleReadiness: GrowthStatus = GrowthStatus.DEVELOPING,
    val communication: GrowthStatus = GrowthStatus.DEVELOPING,
    val careerClarity: GrowthStatus = GrowthStatus.EXPLORE,
    val technicalSkills: GrowthStatus = GrowthStatus.STRONG,
    val collaboration: GrowthStatus = GrowthStatus.DEVELOPING,
    val topPriorities: List<String> = listOf(
        "Trimble Architecture & Connected Construction fundamentals",
        "Stakeholder presentation clarity & concise sprint updates",
        "Setting your first 30-day technical mentor milestones"
    )
)

data class DocumentSource(
    val documentName: String,
    val pageNumber: Int,
    val section: String,
    val topic: String,
    val documentType: String,
    val audience: String,
    val excerpt: String
)

data class ChatMessage(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val sources: List<DocumentSource> = emptyList(),
    val isGeneralGuidance: Boolean = false,
    val intentAnalysis: String? = null,
    val developmentNeed: String? = null,
    val recommendedAction: String? = null,
    val suggestedGoal: String? = null
)

data class Milestone(
    val id: String,
    val title: String,
    val isDone: Boolean = false
)

data class Goal(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val targetDays: Int,
    val milestones: List<Milestone>
) {
    val progress: Float
        get() = if (milestones.isEmpty()) 0f else milestones.count { it.isDone }.toFloat() / milestones.size
}

data class PlanActivity(
    val id: String,
    val title: String,
    val description: String,
    val resourceCitation: String,
    val isCompleted: Boolean = false
)

data class ThirtyDayWeek(
    val weekNumber: Int,
    val title: String,
    val goal: String,
    val activities: List<PlanActivity>
) {
    val progress: Float
        get() = if (activities.isEmpty()) 0f else activities.count { it.isCompleted }.toFloat() / activities.size
}

data class CareerRoadmapStep(
    val phase: String,
    val title: String,
    val description: String,
    val keySkills: List<String>,
    val experiences: List<String>,
    val resources: List<String>
)

data class CommunicationScenario(
    val id: String,
    val title: String,
    val description: String,
    val persona: String, // Manager, Teammate, Stakeholder
    val starterText: String,
    val contextPrompt: String
)

data class RubricScore(
    val category: String,
    val rating: String, // Excellent, Good, Needs Focus
    val observation: String
)

data class ScenarioFeedback(
    val summary: String,
    val rubricScores: List<RubricScore>,
    val polishedAlternative: String,
    val mentorTips: List<String>
)

data class ResourceItem(
    val id: String,
    val title: String,
    val category: String,
    val description: String,
    val documentReference: String,
    val whyItMattersForFreshers: String,
    val recommendedAction: String
)
