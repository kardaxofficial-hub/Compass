package com.example.service

import com.example.BuildConfig
import com.example.model.ChatMessage
import com.example.model.DocumentSource
import com.example.model.UserProfile
import com.example.rag.DocumentSearchEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

object CompassMentorService {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generateMentorResponse(
        userMessage: String,
        userProfile: UserProfile
    ): ChatMessage = withContext(Dispatchers.IO) {
        // Step 1: Retrieve relevant document chunks from authoritative Trimble knowledge base
        val retrievedSources = DocumentSearchEngine.retrieveRelevantChunks(userMessage, maxResults = 3)
        val hasAuthoritativeDocs = retrievedSources.isNotEmpty()

        // Step 2: Try Gemini API if valid key is available
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }
        val isApiKeyValid = apiKey.isNotBlank() && !apiKey.contains("MY_GEMINI_API_KEY")

        if (isApiKeyValid) {
            try {
                val geminiAnswer = callGeminiRestApi(userMessage, userProfile, retrievedSources, apiKey)
                if (geminiAnswer != null) {
                    return@withContext geminiAnswer
                }
            } catch (e: Exception) {
                // Graceful fallback to domain mentor engine
            }
        }

        // Step 3: Domain Mentor Engine ("From information to intention")
        synthesizeMentorGuidance(userMessage, userProfile, retrievedSources)
    }

    private fun callGeminiRestApi(
        userMessage: String,
        userProfile: UserProfile,
        sources: List<DocumentSource>,
        apiKey: String
    ): ChatMessage? {
        val systemPrompt = """
            You are Google Compass, an enterprise AI mentor for new Trimble employees and freshers.
            Employee Profile: ${userProfile.name}, Role: ${userProfile.role}, Experience: ${userProfile.experienceLevel}, Days at Trimble: ${userProfile.daysAtTrimble}, Goal: ${userProfile.careerGoal}.
            
            Core Rule: 'From information to intention.' Never dump raw links. Explain:
            1. What this means
            2. Why it matters
            3. What the employee should do next
            
            Grounded Knowledge:
            ${sources.joinToString("\n---\n") { "${it.documentName} (Page ${it.pageNumber}, Section: ${it.section}): ${it.excerpt}" }}
            
            Tone: Friendly, encouraging, professional, practical, concise.
            If the answer is NOT supported by the retrieved knowledge, explicitly state:
            "I couldn't find an authoritative answer in the available Trimble resources." and clearly label general guidance.
        """.trimIndent()

        val jsonRequest = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", userMessage))
                    })
                })
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", systemPrompt))
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.4)
                put("maxOutputTokens", 1200)
            })
        }

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
            .post(jsonRequest.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        if (response.isSuccessful) {
            val responseBody = response.body?.string() ?: return null
            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val rawText = parts?.optJSONObject(0)?.optString("text")

            if (!rawText.isNullOrBlank()) {
                val hasDocs = sources.isNotEmpty()
                return ChatMessage(
                    id = UUID.randomUUID().toString(),
                    text = rawText,
                    isUser = false,
                    sources = sources,
                    isGeneralGuidance = !hasDocs,
                    intentAnalysis = "Analyzed employee onboarding query via Gemini-grounded synthesis.",
                    developmentNeed = if (hasDocs) "Navigating Trimble organizational knowledge & onboarding milestones" else "General workplace career navigation",
                    recommendedAction = if (hasDocs) "Review the referenced sections in Trimble Learn or schedule a 1:1 check-in with your manager." else "Consult your People Manager or HR Business Partner.",
                    suggestedGoal = "Set a 30-day onboarding milestone around this topic."
                )
            }
        }
        return null
    }

    private fun synthesizeMentorGuidance(
        query: String,
        userProfile: UserProfile,
        sources: List<DocumentSource>
    ): ChatMessage {
        val q = query.lowercase().trim()

        // Match specific intent patterns
        return when {
            // Case 1: The flagship Hackathon demo journey
            q.contains("overwhelm") || (q.contains("start") && q.contains("focus")) || q.contains("where should i start") -> {
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    text = """
                        Welcome to Trimble, ${userProfile.name}! First, take a deep breath. It is completely natural to feel overwhelmed during your first few weeks—Trimble is a vast global organization spanning construction, geospatial, agriculture, and transportation.

                        As a newly joined ${userProfile.role}, your primary goal right now is not to know everything immediately. It's to build strong foundations, understand team rhythms, and establish clarity.

                        Here is how to focus your energy:
                        
                        1. What this means: Your initial 30 days are designed for absorption and learning, not solo delivery pressure.
                        2. Why it matters: Building genuine context on our technology ecosystem (like Trimble Connect and our Snowflake telemetry pipelines) will make all your future data work 10x faster.
                        3. What to do next: Prioritize your core onboarding checklist: finish cyber compliance, meet your onboarding buddy, and shadow your team's upcoming sprint retrospective.
                    """.trimIndent(),
                    isUser = false,
                    sources = sources.ifEmpty {
                        listOf(
                            DocumentSearchEngine.retrieveRelevantChunks("first 30 days checklist", 2)
                        ).flatten()
                    },
                    isGeneralGuidance = false,
                    intentAnalysis = "New hire seeking orientation, prioritization, and reassurance against cognitive overload.",
                    developmentNeed = "Transition from student/fresher mindset into professional onboarding rhythm.",
                    recommendedAction = "Complete the First 30 Days Checklist on Trimble Learn and schedule your recurring weekly 1:1 with ${userProfile.manager}.",
                    suggestedGoal = "Complete Trimble Orientation & schedule 1:1 with Team Buddy by Day 20."
                )
            }

            // Case 2: Mentorship inquiries
            q.contains("mentor") || q.contains("coaching") -> {
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    text = """
                        Finding a mentor at Trimble is one of the most accelerating steps you can take early in your career.

                        1. What this means: Trimble offers both 1:1 cross-functional matching and quarterly Mentoring Circles specifically tailored for freshers and early career professionals.
                        2. Why it matters: Having a mentor outside your immediate management chain provides an open space to ask questions about workplace navigation, career planning, and technical growth without performance pressure.
                        3. What you should do next: Since you have passed your second week, you are officially eligible to request a mentor on the Trimble People Portal under 'Growth & Mentorship'.
                    """.trimIndent(),
                    isUser = false,
                    sources = sources,
                    isGeneralGuidance = false,
                    intentAnalysis = "Employee seeking mentorship connection and guidance on Trimble internal programs.",
                    developmentNeed = "Expanding internal network and seeking professional career mentorship.",
                    recommendedAction = "Visit Trimble People Portal > 'Growth & Mentorship' and submit your profile with your interests (${userProfile.interests.joinToString(", ")}).",
                    suggestedGoal = "Connect with 1 cross-functional mentor and schedule your initial 45-minute discovery sync."
                )
            }

            // Case 3: Communication & Presentations
            q.contains("communicat") || q.contains("present") || q.contains("speak") || q.contains("stakeholder") -> {
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    text = """
                        Communication is often the #1 differentiator for high-performing analysts at Trimble.

                        1. What this means: In an enterprise like Trimble, great communication is structured, asynchronous-first, and focused on business outcomes rather than raw technical complexity.
                        2. Why it matters: Stakeholders need to know the 'Bottom Line Up Front' (BLUF). When presenting analytics, they care about actionable trends and next steps rather than mathematical minutiae.
                        3. What you should do next: Use our Communication Coach module right here in Google Compass to simulate your first project update with a simulated Manager or Stakeholder before presenting live.
                    """.trimIndent(),
                    isUser = false,
                    sources = sources,
                    isGeneralGuidance = false,
                    intentAnalysis = "Seeking guidance on workplace and technical presentation standards.",
                    developmentNeed = "Translating analytical findings into concise executive messaging.",
                    recommendedAction = "Practice in the Communication Coach screen and adopt the BLUF format for your next sprint review update.",
                    suggestedGoal = "Practice 2 project presentation drafts and ask your Team Buddy for constructive feedback."
                )
            }

            // Case 4: Understanding Trimble & Products
            q.contains("understand trimble") || q.contains("what is trimble") || q.contains("products") || q.contains("business unit") -> {
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    text = """
                        Trimble is far more than GPS! Founded in 1978 by Charlie Trimble, our mission is 'Transforming the Way the World Works'.

                        1. What this means: We connect physical and digital workflows across four key industries:
                           • Connected Construction (Tekla, Viewpoint, Trimble Connect cloud)
                           • Geospatial (GNSS surveying, 3D laser mapping, GIS)
                           • Agriculture (Autonomous tractor steering, precision agronomy software)
                           • Transportation (Fleet intelligence, routing algorithms)
                        2. Why it matters: As a ${userProfile.role} in ${userProfile.businessUnit}, your datasets connect directly into our broader IoT telemetry platform.
                        3. What you should do next: Explore the Trimble Connect architecture documentation on Confluence and join the Trimble ECPN tech talk on product architecture this month.
                    """.trimIndent(),
                    isUser = false,
                    sources = sources,
                    isGeneralGuidance = false,
                    intentAnalysis = "Employee seeking big-picture company architecture and industry context.",
                    developmentNeed = "Enterprise domain knowledge and cross-business-unit literacy.",
                    recommendedAction = "Read through Section 'Business Units & Technology Ecosystem' in the Global Orientation Guide.",
                    suggestedGoal = "Map your team's analytical telemetry pipeline to the Trimble Connect platform."
                )
            }

            // Case 5: Becoming a better Data Analyst / Technical growth
            q.contains("data analyst") || q.contains("technical") || q.contains("skills") || q.contains("engineering") -> {
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    text = """
                        Growing into a senior ${userProfile.role} is an intentional journey.

                        1. What this means: Moving from fresher to senior requires moving from simply writing SQL scripts to owning end-to-end telemetry models, understanding data governance in Snowflake, and driving business decisions.
                        2. Why it matters: Trimble operates vast real-time IoT feeds from construction equipment, tractors, and surveyors worldwide. Clean, reliable data is central to our customers' operations.
                        3. What you should do next: Review the Trimble Analytics Style Guide in GitLab, submit your first query for peer review with ${userProfile.mentor}, and activate your enterprise Coursera account.
                    """.trimIndent(),
                    isUser = false,
                    sources = sources,
                    isGeneralGuidance = false,
                    intentAnalysis = "Career development and technical mastery roadmap for Data Analytics.",
                    developmentNeed = "Production engineering rigor, peer review standards, and data governance.",
                    recommendedAction = "Review the 'Data Platform & Tech Stack' documentation and check your Career Compass roadmap.",
                    suggestedGoal = "Submit first analytics notebook for collaborative peer review in GitLab."
                )
            }

            // Case 6: Fallback when not found in Trimble docs
            sources.isEmpty() -> {
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    text = """
                        I couldn't find an authoritative answer in the available Trimble resources regarding this specific inquiry.

                        Here is general professional guidance for freshers:
                        
                        1. What this means: As a new hire, when you encounter policies, internal tools, or questions not covered in standard guides, the best approach is proactive inquiry.
                        2. Why it matters: It demonstrates initiative and prevents working under false assumptions.
                        3. What to do next: I encourage you to check with your People Manager (${userProfile.manager}) or post a quick question in your team's internal Slack channel.
                    """.trimIndent(),
                    isUser = false,
                    sources = emptyList(),
                    isGeneralGuidance = true,
                    intentAnalysis = "Query not covered by official uploaded Trimble policy documents.",
                    developmentNeed = "Clarifying team-specific practices via human manager communication.",
                    recommendedAction = "Consult your People Manager or designated HR Business Partner.",
                    suggestedGoal = "Add this item to your upcoming 1:1 agenda with your manager."
                )
            }

            // Default grounded synthesis
            else -> {
                val primarySource = sources.first()
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    text = """
                        Here is grounded guidance based on Trimble internal resources:

                        ${primarySource.excerpt}

                        1. What this means: This guidance outlines Trimble's official approach to ${primarySource.topic.lowercase()}.
                        2. Why it matters: Understanding these standards early enables you to align smoothly with your team's rhythm and Trimble's core values.
                        3. What to do next: Review the cited document passage in full and consider discussing any open questions during your next 1:1 sync.
                    """.trimIndent(),
                    isUser = false,
                    sources = sources,
                    isGeneralGuidance = false,
                    intentAnalysis = "Grounded query matched with authoritative internal Trimble resources.",
                    developmentNeed = "Adopting Trimble standard practices in daily workflow.",
                    recommendedAction = "Consult the referenced section in ${primarySource.documentName}.",
                    suggestedGoal = "Incorporate this learning into your weekly sprint focus."
                )
            }
        }
    }
}
