package com.example.rag

import com.example.model.DocumentSource

object TrimbleKnowledgeBase {
    val documents: List<DocumentSource> = listOf(
        DocumentSource(
            documentName = "Trimble Global New Hire Orientation (GNH-2026)",
            pageNumber = 4,
            section = "Company Heritage & Mission",
            topic = "Trimble Identity & Core Business",
            documentType = "Official Orientation Guide",
            audience = "All Global New Hires",
            excerpt = "Trimble was founded in 1978 by Charlie Trimble and has evolved from GPS pioneer to a global technology company connecting physical and digital worlds. Our mission is 'Transforming the Way the World Works' across four core industries: Construction, Geospatial, Agriculture, and Transportation. We provide hardware, cloud software, and positioning technologies that increase productivity, safety, and sustainability."
        ),
        DocumentSource(
            documentName = "Trimble Global New Hire Orientation (GNH-2026)",
            pageNumber = 8,
            section = "Core Values & Culture",
            topic = "Trimble Culture",
            documentType = "Official Orientation Guide",
            audience = "All Global New Hires",
            excerpt = "Trimble lives by four foundational culture principles: 1) 'Do What's Right' (integrity and ethical transparency), 2) 'Belonging' (embracing diversity of background and perspective), 3) 'Be Agile' (iterating rapidly and learning from setbacks), and 4) 'Focus on Customer Impact'. Freshers are encouraged to ask questions openly and challenge assumptions during team retrospectives."
        ),
        DocumentSource(
            documentName = "Trimble Global New Hire Orientation (GNH-2026)",
            pageNumber = 12,
            section = "First 30 Days Checklist",
            topic = "New Hire Onboarding",
            documentType = "Official Orientation Guide",
            audience = "New Employees & Freshers",
            excerpt = "In your first 30 days at Trimble: Complete mandatory cybersecurity & compliance modules on Trimble Learn; establish recurring weekly 1:1 syncs with your People Manager; configure your corporate Okta SSO and 2-factor authentication; meet your designated Onboarding Buddy; set your initial 30-day personal goals; and observe at least one cross-functional sprint review."
        ),
        DocumentSource(
            documentName = "Trimble Global New Hire Orientation (GNH-2026)",
            pageNumber = 18,
            section = "Business Units & Technology Ecosystem",
            topic = "Product Architecture",
            documentType = "Official Orientation Guide",
            audience = "Engineers & Analysts",
            excerpt = "Trimble's four key industry segments are: 1) Connected Construction (Tekla Structures, Viewpoint, Trimble Connect collaborative cloud), 2) Geospatial (high-precision GNSS sensors, 3D laser scanners, GIS mapping), 3) Agriculture (autonomous steering, precision farming software, yield telemetry), and 4) Transportation (fleet intelligence, route optimization). Trimble Connect serves as the central data environment integrating these workflows."
        ),
        DocumentSource(
            documentName = "Trimble Mentorship & Growth Handbook",
            pageNumber = 6,
            section = "Finding a Mentor",
            topic = "Mentorship & Career Development",
            documentType = "HR & Talent Development Policy",
            audience = "Early Career & Freshers",
            excerpt = "New hires can request a mentor through the Trimble People Portal under 'Growth & Mentorship'. Freshers are eligible for 1:1 cross-functional matching after their second week. Matches are based on development interests (e.g. Data Engineering, Architecture, Product Management). The recommended cadence is a 45-minute bi-weekly session focused on professional growth, workplace navigation, and technical capability building."
        ),
        DocumentSource(
            documentName = "Trimble Mentorship & Growth Handbook",
            pageNumber = 14,
            section = "Mentoring Circles & Cohorts",
            topic = "Peer & Cohort Mentorship",
            documentType = "HR & Talent Development Policy",
            audience = "Fresher Cohorts",
            excerpt = "In addition to 1:1 mentorship, Trimble hosts quarterly 'Mentoring Circles'—small cohort groups of 4-6 early career employees paired with a Senior Staff Engineer or Product Director. These circles tackle practical workplace challenges such as stakeholder communication, technical ambiguity, and navigating cross-business-unit collaboration."
        ),
        DocumentSource(
            documentName = "Trimble Engineering & Analytics Standards",
            pageNumber = 5,
            section = "Data Platform & Tech Stack",
            topic = "Technical Architecture",
            documentType = "Technical Guideline",
            audience = "Data Analysts, Data Engineers, Software Engineers",
            excerpt = "Trimble's enterprise analytics infrastructure leverages Snowflake as our core analytical warehouse, AWS and GCP data pipelines, and Trimble Connect APIs for IoT telemetry streams. Analytics dashboards are primarily built in Tableau and Apache Superset. All SQL queries and Python transformation notebooks must adhere to the Trimble Analytics Style Guide in GitLab."
        ),
        DocumentSource(
            documentName = "Trimble Engineering & Analytics Standards",
            pageNumber = 11,
            section = "Peer Review & Delivery Standards",
            topic = "Quality & Collaboration",
            documentType = "Technical Guideline",
            audience = "Technical Contributors",
            excerpt = "Every analytical script, model pipeline, or dashboard release requires at least one peer code review before deploying to production. For freshers, code reviews are structured as collaborative learning sessions rather than audits. Senior analysts will provide feedback on modularity, query performance, edge-case validation, and documentation clarity."
        ),
        DocumentSource(
            documentName = "Trimble Workplace Communication & Team Culture Guide",
            pageNumber = 7,
            section = "Async & Team Collaboration Standards",
            topic = "Communication Standards",
            documentType = "Culture & Productivity Guide",
            audience = "All Employees",
            excerpt = "Trimble embraces a hybrid and global work culture. Use public Slack channels rather than private 1:1 messages for project questions so knowledge remains discoverable. When sending status updates to cross-functional leads, follow the BLUF framework: Bottom Line Up Front (1-sentence takeaway, key metrics, dependencies, followed by detailed context). For complex technical queries, draft a concise 1-page design doc."
        ),
        DocumentSource(
            documentName = "Trimble Workplace Communication & Team Culture Guide",
            pageNumber = 15,
            section = "Presenting Project Updates to Stakeholders",
            topic = "Presentation Skills",
            documentType = "Communication Guide",
            audience = "Early Career Presenters",
            excerpt = "When presenting your first project or analytical update to managers and stakeholders: 1) State the business objective in the first 60 seconds, 2) Avoid raw data dumps—highlight the 2-3 most surprising or actionable trends, 3) Explicitly call out next steps and what decisions need to be made, and 4) Welcome questions without being defensive. Practice beforehand with your mentor."
        ),
        DocumentSource(
            documentName = "Trimble Employee Networks & Development Programs",
            pageNumber = 3,
            section = "Early Career Professionals Network (ECPN)",
            topic = "Community & Networking",
            documentType = "Employee Resource Group Guide",
            audience = "New Graduates & Early Career",
            excerpt = "The Early Career Professionals Network (ECPN) is Trimble's dedicated employee resource community for freshers and early-career hires. ECPN hosts monthly tech talks, executive fireside chats, social mixers, and hackathons. Joining your local or virtual chapter is strongly recommended within your first 30 days to build peer support outside your immediate squad."
        ),
        DocumentSource(
            documentName = "Trimble Employee Networks & Development Programs",
            pageNumber = 9,
            section = "Continuous Learning & Tuition Support",
            topic = "Professional Education",
            documentType = "Talent Development Policy",
            audience = "All Full-time Employees",
            excerpt = "All Trimble employees receive complimentary enterprise access to Trimble Learn, Coursera Enterprise, and O'Reilly Learning. Technical employees are allocated 4 hours per month of protected learning time during work hours for self-directed technical upskilling and certification prep."
        )
    )
}
