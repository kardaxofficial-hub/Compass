package com.example.rag

import com.example.model.DocumentSource

object DocumentSearchEngine {

    fun retrieveRelevantChunks(query: String, maxResults: Int = 3): List<DocumentSource> {
        val cleanQuery = query.lowercase().trim()
        val queryTokens = cleanQuery.split("\\s+|[.,?!;:\"'()\\[\\]{}]".toRegex())
            .filter { it.length > 2 }
            .filterNot { it in STOP_WORDS }

        if (queryTokens.isEmpty()) {
            return emptyList()
        }

        val scoredDocs = TrimbleKnowledgeBase.documents.map { doc ->
            var score = 0
            val fullText = "${doc.documentName} ${doc.section} ${doc.topic} ${doc.audience} ${doc.excerpt}".lowercase()

            for (token in queryTokens) {
                if (doc.topic.lowercase().contains(token)) score += 15
                if (doc.section.lowercase().contains(token)) score += 10
                if (doc.excerpt.lowercase().contains(token)) score += 5
                if (doc.documentName.lowercase().contains(token)) score += 3
            }

            // Synonyms & Intent Boosts
            if (cleanQuery.contains("start") || cleanQuery.contains("first") || cleanQuery.contains("30 day") || cleanQuery.contains("begin") || cleanQuery.contains("overwhelm")) {
                if (doc.section.contains("First 30 Days") || doc.topic.contains("Onboarding")) score += 20
            }
            if (cleanQuery.contains("mentor") || cleanQuery.contains("coach") || cleanQuery.contains("guidance")) {
                if (doc.topic.contains("Mentor")) score += 25
            }
            if (cleanQuery.contains("trimble") || cleanQuery.contains("company") || cleanQuery.contains("culture") || cleanQuery.contains("mission")) {
                if (doc.topic.contains("Identity") || doc.topic.contains("Culture")) score += 18
            }
            if (cleanQuery.contains("product") || cleanQuery.contains("business") || cleanQuery.contains("unit") || cleanQuery.contains("tekla") || cleanQuery.contains("connect")) {
                if (doc.topic.contains("Product") || doc.section.contains("Business Units")) score += 20
            }
            if (cleanQuery.contains("communicat") || cleanQuery.contains("present") || cleanQuery.contains("update") || cleanQuery.contains("stakeholder")) {
                if (doc.topic.contains("Communication") || doc.topic.contains("Presentation")) score += 25
            }
            if (cleanQuery.contains("analyst") || cleanQuery.contains("data") || cleanQuery.contains("code") || cleanQuery.contains("sql") || cleanQuery.contains("technical")) {
                if (doc.topic.contains("Technical") || doc.section.contains("Data Platform")) score += 20
            }
            if (cleanQuery.contains("learn") || cleanQuery.contains("course") || cleanQuery.contains("grow") || cleanQuery.contains("ecpn") || cleanQuery.contains("network")) {
                if (doc.topic.contains("Education") || doc.topic.contains("Community")) score += 18
            }

            doc to score
        }

        return scoredDocs
            .filter { it.second > 6 }
            .sortedByDescending { it.second }
            .take(maxResults)
            .map { it.first }
    }

    private val STOP_WORDS = setOf(
        "the", "and", "for", "with", "that", "this", "what", "where", "how", "who", "when",
        "why", "can", "you", "about", "from", "are", "have", "been", "want", "like", "just",
        "some", "will", "would", "should", "could", "into", "onto", "your", "mine", "their"
    )
}
